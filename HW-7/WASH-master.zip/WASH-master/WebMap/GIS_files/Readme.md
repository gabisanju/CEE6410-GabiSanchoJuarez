This folder containts the geodatabase and shapefiles required to build a web map for the Bear River, UT

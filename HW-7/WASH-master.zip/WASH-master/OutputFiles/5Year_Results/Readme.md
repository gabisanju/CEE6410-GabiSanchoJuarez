Files needed to generate results for 5 years optimization 

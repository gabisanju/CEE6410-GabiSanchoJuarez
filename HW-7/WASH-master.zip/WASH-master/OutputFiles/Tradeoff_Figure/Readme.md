Files needed to recreate figure 8: Tradeoff between WASH objective function and demand requirements

This floder contains the following documents:
* ENVSOFT_2017_528_Original_V1(3).pdf: Orignal manuscript submitted to Environmental Modeling and Software
* WASH_Paper_ReSubmit_EMS.doc: Revised manuscript
* Response_Letter.docx: Letter with responses to reviewer comments 
